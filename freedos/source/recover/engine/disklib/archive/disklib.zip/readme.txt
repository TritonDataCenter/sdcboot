                    DISKLIB - The DISK LIBrary
                           26-Dec-1998
                http://www.diskwarez.com/disklib.htm

Due to an increase in demand for and questions about direct disk
access for Micrososft platforms, and due to the fact that Microsoft
has no API for direct disk access, I am releasing this library
much earlier than I intended at that start. I am still working on
this code.

This is the BETA, 0.2, version of DISKLIB, a library of DISK I/O
functions for DOS and Windows. Please read this file in full.


LICENSE

This code can now be distributed to or by BBS, FTP and/or HTTP, as
long it is not done in a commercial manner!

This code can NOT be distributed by Commercial or Shareware web-sites
or as part of a CD-ROM image of any kind.

A full, non-restictive, better written license will be available soon.


NOTES

I hope to eventually offer a "Quality Product", this is just a BETA
version and may just have problems.

If you have any ideas on this subject, or like or use or have fixes
or just want to rap, please send e-mail to: admin@diskwarez.com .


--
Gregg Jennings
26-Dec-1998
This is The DISK LIBrary for MS-DOS and Windows.
Full source code is available at http://www.diskwarez.com/disklib.htm .
